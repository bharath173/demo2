import {Component} from 'angular2/core';
import {StorageService} from './storage.service'

@Component({
    selector: 'register-form',
    providers: [StorageService],
    template: `
            <div class="container" >
                <div class="content">
                    <br />
                <br />
                <br />
                <br /><br />
                    <div style="font-size:300%;color:red">Congratulations, you have successfully Registered in!!</div>
                    <br />
                    <a href="#">Click Here to login</a>
                </div>
            </div>
    	`
})

export class PrivateComponent {

    constructor(
        private _service:StorageService){}

    ngOnInit(){
    }

}
import {Component} from 'angular2/core';
import {StorageService, User} from './storage.service'

@Component({
    selector: 'register-form',
    providers: [StorageService],
    templateUrl:'app/register.html'
})

export class RegisterComponent {

    public user = new User('','','','','','','','','');

    constructor(
        private _service:storageService) {}
    
    save() {
       _service.save(user);
    }
}


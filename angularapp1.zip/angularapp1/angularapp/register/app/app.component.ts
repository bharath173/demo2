import { Component } from '@angular/core';
import {Component} from 'angular2/core';
import {RegisterComponent} from './register.component';
import {PrivateComponent} from './private.component';
import {RouteConfig, ROUTER_DIRECTIVES} from 'angular2/router';

@Component({
    selector: 'my-app',
    directives: [RegisterComponent, ROUTER_DIRECTIVES],
    template: `
            <router-outlet></router-outlet>
        `
})
@RouteConfig([
    { path: '/home', name: 'Home', component: PrivateComponent, useAsDefault:true },
    { path: '/register', name: 'register', component: registerComponent }
])
export class AppComponent {}


import {Injectable} from 'angular2/core';
import {Router} from 'angular2/router';

export class User {
  constructor(
    public firstname: string,
    public lastname: string,
    public username: string,
    public dob: string,
    public email: string,
    public password: string,
    public confpassword: string,
    public secretquestion: string,
    public secretanswer: string) { }
}

var users = [
  new User(firstname,lastname,username,dob,email,password,confpassword,secretquestion,secretanswer),
];

@Injectable()
export class StorageService {

  constructor(
    private _router: Router){}

  

  save(user){
      localStorageService.set(user);
      this._router.navigate(['Home']);      
      return true;
    }

  }

   
}
